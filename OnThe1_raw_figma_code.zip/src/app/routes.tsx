import { createBrowserRouter } from "react-router";
import Root from "./components/Root";
import DetectTab from "./components/detect/DetectTab";
import PracticeHome from "./components/practice/PracticeHome";
import QuickCount from "./components/practice/QuickCount";
import FindThe1 from "./components/practice/FindThe1";
import FindThe1Session from "./components/practice/FindThe1Session";
import LearnTab from "./components/learn/LearnTab";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: Root,
    children: [
      { index: true, Component: DetectTab },
      { path: "practice", Component: PracticeHome },
      { path: "practice/quick-count", Component: QuickCount },
      { path: "practice/find-the-1", Component: FindThe1 },
      { path: "practice/find-the-1/:trackId", Component: FindThe1Session },
      { path: "learn", Component: LearnTab },
    ],
  },
]);
