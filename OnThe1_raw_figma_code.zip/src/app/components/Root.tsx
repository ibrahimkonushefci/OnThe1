import { Outlet, NavLink, useLocation } from "react-router";
import { Radio, Dumbbell, BookOpen } from "lucide-react";

export default function Root() {
  const location = useLocation();

  const getActiveTab = () => {
    if (location.pathname === "/") return "detect";
    if (location.pathname.startsWith("/practice")) return "practice";
    if (location.pathname.startsWith("/learn")) return "learn";
    return "detect";
  };

  const activeTab = getActiveTab();

  return (
    <div className="flex flex-col h-screen bg-background max-w-md mx-auto">
      {/* Main content */}
      <main className="flex-1 overflow-y-auto pb-20">
        <Outlet />
      </main>

      {/* Bottom navigation */}
      <nav className="fixed bottom-0 left-0 right-0 max-w-md mx-auto bg-card border-t border-border">
        <div className="flex items-center justify-around h-20 px-6">
          <NavLink
            to="/"
            className={`flex flex-col items-center gap-1 py-2 px-4 rounded-lg transition-colors ${
              activeTab === "detect"
                ? "text-primary"
                : "text-muted-foreground hover:text-foreground"
            }`}
          >
            <Radio className="w-6 h-6" />
            <span className="text-xs font-medium">Detect</span>
          </NavLink>

          <NavLink
            to="/practice"
            className={`flex flex-col items-center gap-1 py-2 px-4 rounded-lg transition-colors ${
              activeTab === "practice"
                ? "text-primary"
                : "text-muted-foreground hover:text-foreground"
            }`}
          >
            <Dumbbell className="w-6 h-6" />
            <span className="text-xs font-medium">Practice</span>
          </NavLink>

          <NavLink
            to="/learn"
            className={`flex flex-col items-center gap-1 py-2 px-4 rounded-lg transition-colors ${
              activeTab === "learn"
                ? "text-primary"
                : "text-muted-foreground hover:text-foreground"
            }`}
          >
            <BookOpen className="w-6 h-6" />
            <span className="text-xs font-medium">Learn</span>
          </NavLink>
        </div>
      </nav>
    </div>
  );
}
