import { BookOpen, Music, Radio as RadioIcon, Mic, Target } from "lucide-react";

const learningCards = [
  {
    id: 1,
    icon: BookOpen,
    title: "What is the 1?",
    content:
      "The 1 is the beat many dancers use to start the basic step. If you can hear the 1, it becomes easier to enter the dance at the right moment.",
  },
  {
    id: 2,
    icon: RadioIcon,
    title: "How to use Detect",
    content:
      "Hold your phone close enough to the music, wait for the result, then use the cue to start on the next 1.",
  },
  {
    id: 3,
    icon: Music,
    title: "Salsa basics",
    content:
      "A simple Salsa count is 1 2 3, then 5 6 7. Many dancers listen for a strong recurring pulse that helps them find the next phrase.",
  },
  {
    id: 4,
    icon: Music,
    title: "Bachata basics",
    content:
      "A simple Bachata count is 1 2 3 Tap. The tap often gives beginners a clear cycle to follow.",
  },
];

export default function LearnTab() {
  return (
    <div className="min-h-screen px-6 pt-8 pb-6">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-xl font-bold text-foreground mb-2">Learn</h1>
        <p className="text-muted-foreground">
          Short tips to help you hear the beat.
        </p>
      </div>

      {/* Learning Cards */}
      <div className="space-y-4">
        {learningCards.map((card) => {
          const Icon = card.icon;
          return (
            <div
              key={card.id}
              className="bg-card border border-border rounded-2xl p-6 space-y-3"
            >
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0">
                  <Icon className="w-6 h-6 text-primary" />
                </div>
                <div className="flex-1">
                  <h3 className="text-lg font-bold text-foreground mb-2">
                    {card.title}
                  </h3>
                  <p className="text-muted-foreground leading-relaxed">
                    {card.content}
                  </p>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Footer Spacing */}
      <div className="h-8" />
    </div>
  );
}
