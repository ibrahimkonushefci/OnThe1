import { useState, useEffect } from "react";
import { motion } from "motion/react";
import { Mic, MicOff, Settings, AlertCircle } from "lucide-react";
import { Button } from "../ui/Button";
import { Toggle } from "../ui/Toggle";

type DetectState = "idle" | "listening" | "result" | "permission-denied" | "failed";

export default function DetectTab() {
  const [state, setState] = useState<DetectState>("idle");
  const [beepCue, setBeepCue] = useState(true);
  const [vibrationCue, setVibrationCue] = useState(true);
  const [continuousCount, setContinuousCount] = useState(false);
  const [detectedStyle, setDetectedStyle] = useState<"Salsa" | "Bachata" | null>(null);
  const [detectedBPM, setDetectedBPM] = useState<number | null>(null);
  const [beatCount, setBeatCount] = useState(1);

  // Simulate listening and detection
  const handleStartListening = () => {
    setState("listening");
    
    // Simulate detection after 3 seconds
    setTimeout(() => {
      const styles: Array<"Salsa" | "Bachata"> = ["Salsa", "Bachata"];
      const randomStyle = styles[Math.floor(Math.random() * styles.length)];
      const randomBPM = Math.floor(Math.random() * 40) + 80; // 80-120 BPM
      
      setDetectedStyle(randomStyle);
      setDetectedBPM(randomBPM);
      setState("result");
      
      if (continuousCount) {
        startBeating();
      }
    }, 3000);
  };

  const handleStop = () => {
    setState("idle");
    setDetectedStyle(null);
    setDetectedBPM(null);
    setBeatCount(1);
  };

  const startBeating = () => {
    // This would play beep/vibration on each beat
    const interval = setInterval(() => {
      setBeatCount((prev) => (prev >= 8 ? 1 : prev + 1));
    }, 600); // Approximate beat interval

    return () => clearInterval(interval);
  };

  return (
    <div className="min-h-screen px-6 pt-8 pb-6">
      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <h1 className="text-xl font-bold text-foreground">Detect</h1>
        <button className="p-2 text-muted-foreground hover:text-foreground">
          <Settings className="w-5 h-5" />
        </button>
      </div>

      {/* Idle State */}
      {state === "idle" && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="space-y-6"
        >
          {/* Hero Section */}
          <div className="text-center py-8">
            <div className="w-24 h-24 mx-auto mb-6 rounded-full bg-gradient-to-br from-primary/20 to-secondary/20 flex items-center justify-center">
              <Mic className="w-12 h-12 text-primary" />
            </div>
            <h2 className="text-3xl font-bold mb-3 text-foreground">Hear the 1</h2>
            <p className="text-muted-foreground max-w-xs mx-auto">
              Detect Salsa or Bachata and get a cue for when to start.
            </p>
          </div>

          {/* Toggles */}
          <div className="space-y-3">
            <Toggle label="Beep cue" checked={beepCue} onCheckedChange={setBeepCue} />
            <Toggle label="Vibration cue" checked={vibrationCue} onCheckedChange={setVibrationCue} />
            <div>
              <Toggle label="Continuous count" checked={continuousCount} onCheckedChange={setContinuousCount} />
              <p className="text-sm text-muted-foreground mt-1 ml-1">
                Keeps counting after the start cue
              </p>
            </div>
          </div>

          {/* Main Action */}
          <Button size="large" onClick={handleStartListening} className="w-full">
            Start Listening
          </Button>

          {/* Helper Text */}
          <p className="text-sm text-muted-foreground text-center px-4">
            Best results come from a steady part of the song with a clear beat.
          </p>
        </motion.div>
      )}

      {/* Listening State */}
      {state === "listening" && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="space-y-8 text-center py-12"
        >
          <motion.div
            className="w-32 h-32 mx-auto rounded-full bg-gradient-to-br from-primary/20 to-secondary/20 flex items-center justify-center"
            animate={{
              scale: [1, 1.1, 1],
              opacity: [0.8, 1, 0.8],
            }}
            transition={{
              duration: 1.5,
              repeat: Infinity,
              ease: "easeInOut",
            }}
          >
            <Mic className="w-16 h-16 text-primary" />
          </motion.div>

          <div>
            <h2 className="text-3xl font-bold mb-3 text-foreground">Listening...</h2>
            <p className="text-muted-foreground max-w-xs mx-auto">
              Trying to estimate dance style, BPM, and the 1.
            </p>
          </div>

          <Button variant="secondary" onClick={handleStop} className="mx-auto">
            Stop
          </Button>
        </motion.div>
      )}

      {/* Result State */}
      {state === "result" && detectedStyle && detectedBPM && (
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="space-y-6"
        >
          {/* Hero Section */}
          <div className="text-center py-6">
            <div className="w-24 h-24 mx-auto mb-6 rounded-full bg-gradient-to-br from-primary/20 to-secondary/20 flex items-center justify-center">
              <Mic className="w-12 h-12 text-primary" />
            </div>
            <h2 className="text-3xl font-bold mb-6 text-foreground">Hear the 1</h2>
          </div>

          {/* Result Card */}
          <div className="bg-card border border-border rounded-2xl p-6 space-y-4">
            <div className="flex items-center gap-3">
              <span className="px-4 py-2 bg-secondary/20 text-secondary rounded-full text-sm font-semibold">
                {detectedStyle}
              </span>
            </div>

            <div>
              <p className="text-sm text-muted-foreground mb-1">Estimated BPM</p>
              <p className="text-4xl font-bold text-primary">{detectedBPM} BPM</p>
            </div>

            <div className="pt-4 border-t border-border space-y-2">
              <p className="text-foreground font-medium">
                Get ready to start on the next 1
              </p>
              <p className="text-sm text-primary">
                {continuousCount ? "Continuous count is on" : "Start cue ready"}
              </p>
            </div>

            {/* Beat Counter Display */}
            {continuousCount && (
              <div className="flex items-center justify-center gap-3 pt-4">
                {[1, 2, 3, 4, 5, 6, 7, 8].map((num) => (
                  <motion.div
                    key={num}
                    className={`w-10 h-10 rounded-full flex items-center justify-center font-bold transition-all ${
                      beatCount === num
                        ? "bg-primary text-primary-foreground scale-110"
                        : "bg-muted/50 text-muted-foreground"
                    }`}
                    animate={beatCount === num ? { scale: [1, 1.15, 1] } : {}}
                    transition={{ duration: 0.2 }}
                  >
                    {num}
                  </motion.div>
                ))}
              </div>
            )}
          </div>

          {/* Actions */}
          <div className="space-y-3">
            <Button size="large" onClick={handleStartListening} className="w-full">
              Listen Again
            </Button>
            {continuousCount && (
              <Button variant="secondary" onClick={handleStop} className="w-full">
                Stop Count
              </Button>
            )}
          </div>
        </motion.div>
      )}

      {/* Permission Denied State */}
      {state === "permission-denied" && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="space-y-6 text-center py-12"
        >
          <div className="w-24 h-24 mx-auto rounded-full bg-destructive/20 flex items-center justify-center">
            <MicOff className="w-12 h-12 text-destructive" />
          </div>

          <div>
            <h2 className="text-2xl font-bold mb-3 text-foreground">
              Microphone access is off
            </h2>
            <p className="text-muted-foreground max-w-xs mx-auto">
              OnThe1 needs microphone access to listen to the music around you.
            </p>
          </div>

          <div className="space-y-3 max-w-xs mx-auto">
            <Button size="large" className="w-full">
              Open Settings
            </Button>
            <Button variant="secondary" onClick={() => setState("idle")} className="w-full">
              Try Again
            </Button>
          </div>
        </motion.div>
      )}

      {/* Failed Detection State */}
      {state === "failed" && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="space-y-6 text-center py-12"
        >
          <div className="w-24 h-24 mx-auto rounded-full bg-warning/20 flex items-center justify-center">
            <AlertCircle className="w-12 h-12 text-warning" />
          </div>

          <div>
            <h2 className="text-2xl font-bold mb-3 text-foreground">
              Could not read the rhythm
            </h2>
            <p className="text-muted-foreground max-w-xs mx-auto">
              Try again when the music is louder or steadier.
            </p>
          </div>

          <Button size="large" onClick={() => setState("idle")} className="mx-auto">
            Try Again
          </Button>
        </motion.div>
      )}
    </div>
  );
}
