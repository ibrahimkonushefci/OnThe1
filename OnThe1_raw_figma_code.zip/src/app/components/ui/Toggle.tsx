import { Switch } from "@radix-ui/react-switch";

interface ToggleProps {
  label: string;
  checked: boolean;
  onCheckedChange: (checked: boolean) => void;
}

export function Toggle({ label, checked, onCheckedChange }: ToggleProps) {
  return (
    <div className="flex items-center justify-between py-3 px-4 bg-card rounded-xl border border-border">
      <span className="text-foreground font-medium">{label}</span>
      <Switch
        checked={checked}
        onCheckedChange={onCheckedChange}
        className={`w-11 h-6 rounded-full transition-colors ${
          checked ? "bg-primary" : "bg-muted"
        }`}
      >
        <span
          className={`block w-5 h-5 rounded-full bg-white shadow-lg transition-transform ${
            checked ? "translate-x-5" : "translate-x-0.5"
          }`}
          style={{ transform: checked ? "translateX(20px)" : "translateX(2px)" }}
        />
      </Switch>
    </div>
  );
}
