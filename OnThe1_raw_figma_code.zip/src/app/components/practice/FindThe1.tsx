import { Link } from "react-router";
import { ChevronLeft, Play } from "lucide-react";

type Track = {
  id: string;
  title: string;
  style: "Salsa" | "Bachata";
  bpm: number;
};

const tracks: Track[] = [
  { id: "1", title: "Salsa Basic 1", style: "Salsa", bpm: 85 },
  { id: "2", title: "Salsa Basic 2", style: "Salsa", bpm: 92 },
  { id: "3", title: "Salsa Midtempo", style: "Salsa", bpm: 105 },
  { id: "4", title: "Bachata Basic 1", style: "Bachata", bpm: 110 },
  { id: "5", title: "Bachata Basic 2", style: "Bachata", bpm: 118 },
  { id: "6", title: "Bachata Midtempo", style: "Bachata", bpm: 125 },
];

export default function FindThe1() {
  return (
    <div className="min-h-screen px-6 pt-8 pb-6">
      {/* Header */}
      <div className="flex items-center gap-4 mb-6">
        <Link to="/practice" className="p-2 -ml-2 text-foreground hover:text-primary">
          <ChevronLeft className="w-6 h-6" />
        </Link>
        <h1 className="text-xl font-bold text-foreground">Find the 1</h1>
      </div>

      <p className="text-muted-foreground mb-6">
        Listen to the track and tap when you think the 1 lands.
      </p>

      {/* Track List */}
      <div className="space-y-3">
        {tracks.map((track) => (
          <Link
            key={track.id}
            to={`/practice/find-the-1/${track.id}`}
            className="block"
          >
            <div className="bg-card border border-border rounded-xl p-5 hover:border-primary/50 transition-colors">
              <div className="flex items-center justify-between">
                <div className="flex-1">
                  <h3 className="font-semibold text-foreground mb-2">{track.title}</h3>
                  <div className="flex items-center gap-3 text-sm">
                    <span className={`px-3 py-1 rounded-full ${
                      track.style === "Salsa" 
                        ? "bg-primary/20 text-primary" 
                        : "bg-secondary/20 text-secondary"
                    }`}>
                      {track.style}
                    </span>
                    <span className="text-muted-foreground">{track.bpm} BPM</span>
                  </div>
                </div>
                <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center ml-4">
                  <Play className="w-5 h-5 text-primary fill-primary" />
                </div>
              </div>
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
}
