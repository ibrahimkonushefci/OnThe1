import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Link, useParams, useNavigate } from "react-router";
import { ChevronLeft, Play, Pause, RotateCcw, Home, Circle } from "lucide-react";
import { Button } from "../ui/Button";

type SessionState = "playing" | "complete";
type TapResult = "perfect" | "good" | "early" | "late";

interface TapFeedback {
  result: TapResult;
  offset: number;
}

const tracks = {
  "1": { title: "Salsa Basic 1", style: "Salsa", bpm: 85 },
  "2": { title: "Salsa Basic 2", style: "Salsa", bpm: 92 },
  "3": { title: "Salsa Midtempo", style: "Salsa", bpm: 105 },
  "4": { title: "Bachata Basic 1", style: "Bachata", bpm: 110 },
  "5": { title: "Bachata Basic 2", style: "Bachata", bpm: 118 },
  "6": { title: "Bachata Midtempo", style: "Bachata", bpm: 125 },
};

export default function FindThe1Session() {
  const { trackId } = useParams<{ trackId: string }>();
  const navigate = useNavigate();
  const track = trackId ? tracks[trackId as keyof typeof tracks] : null;

  const [state, setState] = useState<SessionState>("playing");
  const [isPlaying, setIsPlaying] = useState(true);
  const [progress, setProgress] = useState(0);
  const [beatCount, setBeatCount] = useState(1);
  const [taps, setTaps] = useState<TapFeedback[]>([]);
  const [lastTapResult, setLastTapResult] = useState<TapResult | null>(null);
  const [stats, setStats] = useState({
    perfect: 0,
    good: 0,
    early: 0,
    late: 0,
  });

  // Simulate track playback
  useEffect(() => {
    if (!isPlaying || state === "complete" || !track) return;

    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          setState("complete");
          setIsPlaying(false);
          return 100;
        }
        return prev + 2; // Increment by 2% every interval
      });
    }, 300);

    return () => clearInterval(interval);
  }, [isPlaying, state, track]);

  // Simulate beat counting
  useEffect(() => {
    if (!isPlaying || !track) return;

    const bpm = track.bpm;
    const interval = 60000 / bpm;

    const timer = setInterval(() => {
      setBeatCount((prev) => (prev >= 8 ? 1 : prev + 1));
    }, interval);

    return () => clearInterval(timer);
  }, [isPlaying, track]);

  const handleTap = () => {
    // Simulate tap accuracy
    const results: TapResult[] = ["perfect", "good", "early", "late"];
    const weights = [0.3, 0.4, 0.15, 0.15]; // Probability distribution
    const random = Math.random();
    let cumulative = 0;
    let result: TapResult = "good";

    for (let i = 0; i < results.length; i++) {
      cumulative += weights[i];
      if (random <= cumulative) {
        result = results[i];
        break;
      }
    }

    const offset = Math.floor(Math.random() * 100) - 50; // -50 to 50ms
    
    setLastTapResult(result);
    setTaps([...taps, { result, offset }]);
    setStats((prev) => ({
      ...prev,
      [result]: prev[result] + 1,
    }));

    // Clear tap result after animation
    setTimeout(() => setLastTapResult(null), 500);
  };

  const handleTryAgain = () => {
    setProgress(0);
    setBeatCount(1);
    setTaps([]);
    setLastTapResult(null);
    setStats({ perfect: 0, good: 0, early: 0, late: 0 });
    setState("playing");
    setIsPlaying(true);
  };

  if (!track) {
    return <div>Track not found</div>;
  }

  const totalTaps = stats.perfect + stats.good + stats.early + stats.late;
  const hitRate = totalTaps > 0 ? ((stats.perfect + stats.good) / totalTaps) * 100 : 0;
  const avgOffset = taps.length > 0 
    ? Math.abs(taps.reduce((sum, tap) => sum + tap.offset, 0) / taps.length) 
    : 0;

  return (
    <div className="min-h-screen px-6 pt-8 pb-6">
      {state === "playing" && (
        <>
          {/* Header */}
          <div className="flex items-center justify-between mb-6">
            <Link to="/practice/find-the-1" className="p-2 -ml-2 text-foreground hover:text-primary">
              <ChevronLeft className="w-6 h-6" />
            </Link>
            <h2 className="text-lg font-semibold text-foreground">{track.title}</h2>
            <div className="w-10" /> {/* Spacer */}
          </div>

          {/* Progress Bar */}
          <div className="mb-6">
            <div className="h-2 bg-muted rounded-full overflow-hidden">
              <motion.div
                className="h-full bg-primary"
                initial={{ width: "0%" }}
                animate={{ width: `${progress}%` }}
                transition={{ duration: 0.3 }}
              />
            </div>
          </div>

          {/* Current Stats Preview */}
          <div className="bg-card border border-border rounded-xl p-4 mb-6">
            <div className="flex justify-between items-center text-sm">
              <div>
                <p className="text-muted-foreground">Taps</p>
                <p className="text-xl font-bold text-foreground">{totalTaps}</p>
              </div>
              <div>
                <p className="text-muted-foreground">Hit Rate</p>
                <p className="text-xl font-bold text-success">{hitRate.toFixed(0)}%</p>
              </div>
              <div>
                <p className="text-muted-foreground">Perfect</p>
                <p className="text-xl font-bold text-primary">{stats.perfect}</p>
              </div>
            </div>
          </div>

          {/* Tap Target */}
          <div className="flex flex-col items-center justify-center py-12">
            <motion.button
              onClick={handleTap}
              className="relative w-64 h-64 rounded-full bg-gradient-to-br from-primary/30 to-secondary/30 border-4 border-primary flex items-center justify-center"
              whileTap={{ scale: 0.9 }}
              animate={beatCount === 1 ? { scale: [1, 1.05, 1] } : {}}
              transition={{ duration: 0.2 }}
            >
              <Circle className="w-24 h-24 text-primary" strokeWidth={3} />
              <span className="absolute bottom-8 text-sm font-semibold text-muted-foreground uppercase tracking-wider">
                Tap on the 1
              </span>
            </motion.button>

            {/* Tap Feedback */}
            <AnimatePresence>
              {lastTapResult && (
                <motion.div
                  initial={{ opacity: 0, scale: 0.8, y: 20 }}
                  animate={{ opacity: 1, scale: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.8, y: -20 }}
                  className={`mt-8 px-8 py-4 rounded-full font-bold text-xl ${
                    lastTapResult === "perfect"
                      ? "bg-primary text-primary-foreground"
                      : lastTapResult === "good"
                      ? "bg-success text-success-foreground"
                      : lastTapResult === "early"
                      ? "bg-warning text-warning-foreground"
                      : "bg-warning text-warning-foreground"
                  }`}
                >
                  {lastTapResult === "perfect"
                    ? "PERFECT!"
                    : lastTapResult === "good"
                    ? "GOOD!"
                    : lastTapResult === "early"
                    ? "EARLY"
                    : "LATE"}
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* Playback Controls */}
          <div className="flex items-center justify-center gap-4 mt-8">
            <button
              onClick={() => setIsPlaying(!isPlaying)}
              className="w-14 h-14 rounded-full bg-muted flex items-center justify-center hover:bg-muted/80 transition-colors"
            >
              {isPlaying ? (
                <Pause className="w-6 h-6 text-foreground" />
              ) : (
                <Play className="w-6 h-6 text-foreground fill-foreground" />
              )}
            </button>
          </div>
        </>
      )}

      {state === "complete" && (
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="space-y-6"
        >
          {/* Header */}
          <div className="text-center py-6">
            <div className="w-20 h-20 mx-auto mb-4 rounded-full bg-gradient-to-br from-primary/20 to-secondary/20 flex items-center justify-center">
              <Circle className="w-10 h-10 text-primary" strokeWidth={3} />
            </div>
            <h2 className="text-3xl font-bold text-foreground">Session Complete</h2>
          </div>

          {/* Stats Card */}
          <div className="bg-card border border-border rounded-2xl p-6 space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-primary/10 rounded-xl p-4 text-center">
                <p className="text-sm text-muted-foreground mb-1">Perfect Taps</p>
                <p className="text-3xl font-bold text-primary">{stats.perfect}</p>
              </div>
              <div className="bg-success/10 rounded-xl p-4 text-center">
                <p className="text-sm text-muted-foreground mb-1">Good Taps</p>
                <p className="text-3xl font-bold text-success">{stats.good}</p>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="bg-muted rounded-xl p-4 text-center">
                <p className="text-sm text-muted-foreground mb-1">Early Taps</p>
                <p className="text-2xl font-bold text-foreground">{stats.early}</p>
              </div>
              <div className="bg-muted rounded-xl p-4 text-center">
                <p className="text-sm text-muted-foreground mb-1">Late Taps</p>
                <p className="text-2xl font-bold text-foreground">{stats.late}</p>
              </div>
            </div>

            <div className="pt-4 border-t border-border space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-muted-foreground">Hit Rate</span>
                <span className="text-xl font-bold text-foreground">{hitRate.toFixed(1)}%</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-muted-foreground">Average Offset</span>
                <span className="text-xl font-bold text-foreground">{avgOffset.toFixed(0)}ms</span>
              </div>
            </div>
          </div>

          {/* Actions */}
          <div className="space-y-3">
            <Button size="large" onClick={handleTryAgain} className="w-full">
              <RotateCcw className="w-5 h-5 mr-2" />
              Try Again
            </Button>
            <Button
              variant="secondary"
              size="large"
              onClick={() => navigate("/practice")}
              className="w-full"
            >
              <Home className="w-5 h-5 mr-2" />
              Back to Practice
            </Button>
          </div>
        </motion.div>
      )}
    </div>
  );
}
