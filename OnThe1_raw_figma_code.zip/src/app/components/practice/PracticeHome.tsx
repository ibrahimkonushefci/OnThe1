import { Link } from "react-router";
import { Timer, Target, ArrowRight } from "lucide-react";
import { Button } from "../ui/Button";

export default function PracticeHome() {
  return (
    <div className="min-h-screen px-6 pt-8 pb-6">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-xl font-bold text-foreground mb-2">Practice</h1>
        <p className="text-muted-foreground">
          Train your ear before you hit the dance floor.
        </p>
      </div>

      {/* Practice Cards */}
      <div className="space-y-4">
        {/* Quick Count Card */}
        <div className="bg-card border border-border rounded-2xl p-6 space-y-4">
          <div className="w-14 h-14 rounded-full bg-primary/20 flex items-center justify-center">
            <Timer className="w-7 h-7 text-primary" />
          </div>
          
          <div>
            <h3 className="text-xl font-bold text-foreground mb-2">Quick Count</h3>
            <p className="text-muted-foreground">
              Choose a style and tempo, then follow the count.
            </p>
          </div>

          <Link to="/practice/quick-count">
            <Button variant="primary" className="w-full group">
              Open Quick Count
              <ArrowRight className="w-4 h-4 ml-2 inline group-hover:translate-x-1 transition-transform" />
            </Button>
          </Link>
        </div>

        {/* Find the 1 Card */}
        <div className="bg-card border border-border rounded-2xl p-6 space-y-4">
          <div className="w-14 h-14 rounded-full bg-secondary/20 flex items-center justify-center">
            <Target className="w-7 h-7 text-secondary" />
          </div>
          
          <div>
            <h3 className="text-xl font-bold text-foreground mb-2">Find the 1</h3>
            <p className="text-muted-foreground">
              Play a practice track and tap when you think the 1 lands.
            </p>
          </div>

          <Link to="/practice/find-the-1">
            <Button variant="primary" className="w-full group">
              Open Trainer
              <ArrowRight className="w-4 h-4 ml-2 inline group-hover:translate-x-1 transition-transform" />
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
}
