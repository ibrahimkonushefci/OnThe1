import { useState, useEffect } from "react";
import { motion } from "motion/react";
import { ChevronLeft } from "lucide-react";
import { Link } from "react-router";
import { Button } from "../ui/Button";
import { Toggle } from "../ui/Toggle";
import * as Slider from "@radix-ui/react-slider";

type DanceStyle = "Salsa" | "Bachata";

export default function QuickCount() {
  const [isRunning, setIsRunning] = useState(false);
  const [style, setStyle] = useState<DanceStyle>("Salsa");
  const [tempo, setTempo] = useState(100);
  const [beepCue, setBeepCue] = useState(true);
  const [vibrationCue, setVibrationCue] = useState(true);
  const [beatCount, setBeatCount] = useState(1);

  useEffect(() => {
    if (!isRunning) return;

    const bpm = tempo;
    const interval = 60000 / bpm; // milliseconds per beat

    const timer = setInterval(() => {
      setBeatCount((prev) => (prev >= 8 ? 1 : prev + 1));
    }, interval);

    return () => clearInterval(timer);
  }, [isRunning, tempo]);

  const handleStart = () => {
    setBeatCount(1);
    setIsRunning(true);
  };

  const handleStop = () => {
    setIsRunning(false);
    setBeatCount(1);
  };

  return (
    <div className="min-h-screen px-6 pt-8 pb-6">
      {/* Header */}
      <div className="flex items-center gap-4 mb-8">
        <Link to="/practice" className="p-2 -ml-2 text-foreground hover:text-primary">
          <ChevronLeft className="w-6 h-6" />
        </Link>
        <h1 className="text-xl font-bold text-foreground">Quick Count</h1>
      </div>

      {!isRunning ? (
        <div className="space-y-6">
          <p className="text-muted-foreground">
            Pick a dance and tempo, then follow the beat.
          </p>

          {/* Style Selector */}
          <div>
            <label className="block text-foreground font-medium mb-3">Dance Style</label>
            <div className="flex gap-3">
              <button
                onClick={() => setStyle("Salsa")}
                className={`flex-1 py-4 px-6 rounded-xl font-semibold transition-all ${
                  style === "Salsa"
                    ? "bg-primary text-primary-foreground"
                    : "bg-muted text-foreground hover:bg-muted/80"
                }`}
              >
                Salsa
              </button>
              <button
                onClick={() => setStyle("Bachata")}
                className={`flex-1 py-4 px-6 rounded-xl font-semibold transition-all ${
                  style === "Bachata"
                    ? "bg-primary text-primary-foreground"
                    : "bg-muted text-foreground hover:bg-muted/80"
                }`}
              >
                Bachata
              </button>
            </div>
          </div>

          {/* Tempo Slider */}
          <div>
            <label className="block text-foreground font-medium mb-3">Tempo</label>
            <div className="bg-card border border-border rounded-xl p-6">
              <div className="flex items-center justify-between mb-4">
                <span className="text-4xl font-bold text-primary">{tempo} BPM</span>
              </div>
              <Slider.Root
                className="relative flex items-center w-full h-5"
                value={[tempo]}
                onValueChange={(value) => setTempo(value[0])}
                min={60}
                max={140}
                step={1}
              >
                <Slider.Track className="relative h-2 flex-grow bg-muted rounded-full">
                  <Slider.Range className="absolute h-full bg-primary rounded-full" />
                </Slider.Track>
                <Slider.Thumb className="block w-5 h-5 bg-primary rounded-full shadow-lg hover:bg-primary/90 focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2 focus:ring-offset-background" />
              </Slider.Root>
              <div className="flex justify-between mt-2 text-xs text-muted-foreground">
                <span>60</span>
                <span>140</span>
              </div>
            </div>
          </div>

          {/* Toggles */}
          <div className="space-y-3">
            <Toggle label="Beep cue" checked={beepCue} onCheckedChange={setBeepCue} />
            <Toggle label="Vibration cue" checked={vibrationCue} onCheckedChange={setVibrationCue} />
          </div>

          {/* Start Button */}
          <Button size="large" onClick={handleStart} className="w-full">
            Start Count
          </Button>
        </div>
      ) : (
        <div className="space-y-8">
          {/* Style Badge */}
          <div className="flex justify-center">
            <span className="px-6 py-3 bg-secondary/20 text-secondary rounded-full text-lg font-semibold">
              {style}
            </span>
          </div>

          {/* BPM Display */}
          <div className="text-center">
            <p className="text-muted-foreground mb-2">Tempo</p>
            <p className="text-5xl font-bold text-primary">{tempo} BPM</p>
          </div>

          {/* Rhythm Display */}
          <div className="py-8 px-2">
            {style === "Salsa" ? (
              <div className="flex items-center justify-center gap-3">
                {/* First phrase: 1 2 3 */}
                <div className="flex gap-2">
                  {[1, 2, 3].map((num) => (
                    <motion.div
                      key={num}
                      className={`w-16 h-16 rounded-xl flex items-center justify-center text-2xl font-bold transition-all ${
                        beatCount === num
                          ? num === 1
                            ? "bg-primary text-primary-foreground ring-4 ring-primary/50"
                            : "bg-primary text-primary-foreground"
                          : num === 1
                          ? "bg-muted/30 text-muted-foreground ring-2 ring-primary/30"
                          : "bg-muted/30 text-muted-foreground"
                      }`}
                      animate={beatCount === num ? { scale: [1, 1.15, 1] } : {}}
                      transition={{ duration: 0.15 }}
                    >
                      {num}
                    </motion.div>
                  ))}
                </div>

                {/* Pause indicator */}
                <div className="w-2 h-2 rounded-full bg-muted-foreground/30" />

                {/* Second phrase: 5 6 7 */}
                <div className="flex gap-2">
                  {[5, 6, 7].map((num) => (
                    <motion.div
                      key={num}
                      className={`w-16 h-16 rounded-xl flex items-center justify-center text-2xl font-bold transition-all ${
                        beatCount === num
                          ? "bg-primary text-primary-foreground"
                          : "bg-muted/30 text-muted-foreground"
                      }`}
                      animate={beatCount === num ? { scale: [1, 1.15, 1] } : {}}
                      transition={{ duration: 0.15 }}
                    >
                      {num}
                    </motion.div>
                  ))}
                </div>
              </div>
            ) : (
              <div className="flex items-center justify-center gap-2">
                {/* First phrase: 1 2 3 Tap */}
                <div className="flex gap-1.5">
                  {[1, 2, 3].map((num) => (
                    <motion.div
                      key={num}
                      className={`w-14 h-14 rounded-xl flex items-center justify-center text-xl font-bold transition-all ${
                        beatCount === num
                          ? num === 1
                            ? "bg-primary text-primary-foreground ring-4 ring-primary/50"
                            : "bg-primary text-primary-foreground"
                          : num === 1
                          ? "bg-muted/30 text-muted-foreground ring-2 ring-primary/30"
                          : "bg-muted/30 text-muted-foreground"
                      }`}
                      animate={beatCount === num ? { scale: [1, 1.15, 1] } : {}}
                      transition={{ duration: 0.15 }}
                    >
                      {num}
                    </motion.div>
                  ))}
                  <motion.div
                    className={`w-14 h-14 rounded-xl flex items-center justify-center text-xs font-semibold transition-all ${
                      beatCount === 4
                        ? "bg-secondary text-secondary-foreground"
                        : "bg-muted/20 text-muted-foreground"
                    }`}
                    animate={beatCount === 4 ? { scale: [1, 1.15, 1] } : {}}
                    transition={{ duration: 0.15 }}
                  >
                    Tap
                  </motion.div>
                </div>

                {/* Pause indicator */}
                <div className="w-2 h-2 rounded-full bg-muted-foreground/30" />

                {/* Second phrase: 5 6 7 Tap */}
                <div className="flex gap-1.5">
                  {[5, 6, 7].map((num) => (
                    <motion.div
                      key={num}
                      className={`w-14 h-14 rounded-xl flex items-center justify-center text-xl font-bold transition-all ${
                        beatCount === num
                          ? "bg-primary text-primary-foreground"
                          : "bg-muted/30 text-muted-foreground"
                      }`}
                      animate={beatCount === num ? { scale: [1, 1.15, 1] } : {}}
                      transition={{ duration: 0.15 }}
                    >
                      {num}
                    </motion.div>
                  ))}
                  <motion.div
                    className={`w-14 h-14 rounded-xl flex items-center justify-center text-xs font-semibold transition-all ${
                      beatCount === 8
                        ? "bg-secondary text-secondary-foreground"
                        : "bg-muted/20 text-muted-foreground"
                    }`}
                    animate={beatCount === 8 ? { scale: [1, 1.15, 1] } : {}}
                    transition={{ duration: 0.15 }}
                  >
                    Tap
                  </motion.div>
                </div>
              </div>
            )}
          </div>

          {/* Stop Button */}
          <Button variant="secondary" size="large" onClick={handleStop} className="w-full">
            Stop
          </Button>
        </div>
      )}
    </div>
  );
}
