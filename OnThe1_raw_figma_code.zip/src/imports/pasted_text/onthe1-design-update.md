Update the existing OnThe1 mobile app design based on the current screens, but keep the same overall visual direction, dark theme, cyan primary accent, simple layout, and beginner-friendly feel.

Goal:
Refine the current design so it is clearer, more useful for real dancers, and more accurate to Salsa/Bachata rhythm learning. Do not redesign from scratch. Improve the existing screens.

General design rules:
- Keep the current dark UI style and overall structure
- Keep the app beginner-friendly and simple
- Prioritize clarity over decoration
- Keep the design iOS-first
- Keep the bottom tabs: Detect, Practice, Learn
- Keep the current modern, minimal, music-focused look
- Maintain strong contrast and readability in low-light environments
- Keep spacing generous and the layout clean
- Use clear hierarchy for headlines, helper text, states, and actions

Important product context:
OnThe1 helps beginner social dancers hear the beat, identify whether music is Salsa or Bachata, find the “1”, and know when to start dancing.

Please update the following screens and details:

1. Detect start screen
Keep the current layout, but improve the messaging clarity.

Current headline:
- Hear the 1

Keep this headline if it still fits visually, but add clearer supporting copy underneath so a beginner instantly understands what the app does.

Replace the subtitle with something clearer, such as:
- Detect Salsa or Bachata and get a cue for when to start.
or

Also improve the helper text near the bottom:
Current:
- Best results come from a steady section of the song with clear rhythm.
Change to something simpler and more natural:
- Best results come from a steady part of the song with a clear beat.

Keep the toggles:
- Beep cue
- Vibration cue
- Continuous count

But make the Continuous count option easier to understand by adding helper text or secondary text explaining:
- Keeps counting after the start cue

2. Detect result screen
Keep the card layout and style, but make the result state more informative.

Current result shows:
- dance style
- BPM
- Get ready to start on the next 1

Improve this result state by making it clearer what happens next.
Add one supportive status line such as:
- Cue active
- Listening for the next 1
- Start cue ready
- Continuous count is on

If Continuous count is enabled, the UI should reflect that clearly.
If Continuous count is off, the result should still clearly communicate that the app will only cue the next 1.

The result state should feel more active and useful, not static.

3. Practice home screen
Keep the current structure:
- Quick Count
- Find the 1

This screen is already strong. Keep it mostly the same.

Only make sure:
- the cards feel visually consistent
- the descriptions are concise and clear
- the CTA buttons remain strong and obvious

4. Quick Count setup screen
Keep the existing structure:
- dance style selection
- tempo slider
- beep cue toggle
- vibration cue toggle
- start button

This screen is good overall.
Only improve spacing and clarity if needed.

5. Quick Count active screen
This is the main screen that should be changed.

The current 1–8 box grid looks clean, but it is too generic and not musically ideal for Salsa and Bachata beginners.

Redesign this screen so the rhythm display matches the dance better.

For Salsa:
- show grouped rhythm like: 1 2 3   •   5 6 7
- visually highlight the current beat
- make the “1” especially clear
- if there is a pause or break between phrases, represent it cleanly

For Bachata:
- show grouped rhythm like: 1 2 3 Tap   •   5 6 7 Tap
- highlight the current beat
- make the Tap visually distinct from the numbered beats if helpful

Do not use a generic 8-box grid as the main rhythm display anymore.

The active Quick Count screen should feel more like a live rhythm guide and less like a number board.

Keep:
- dance style label
- tempo display
- stop button

But redesign the middle section into a more musically correct rhythm visualization.

6. Find the 1 list screen
Keep the current list structure and visual style.

This screen works well.
Just ensure the track cards are consistent and readable.

Optional small improvement:
- make the play button, track title, BPM, and style tag more polished and aligned

7. Find the 1 active trainer screen
Keep the overall structure and the large tap target, but improve real-time feedback.

Add clearer live feedback after each tap, such as:
- Perfect
- Early
- Late

This feedback should appear immediately after a tap and be easy to understand.

Consider adding:
- a small temporary label near the tap target
- a subtle flash or visual response after tapping
- a “last tap result” area

Keep the existing stats area, but make the session feel more alive and more game-like without becoming cluttered.

Keep the instruction:
- Tap on the 1
or a polished version of it.

8. Learn screen
Keep the card-based layout and overall visual direction.

Reorder the cards so the content flows better for beginners.

Recommended order:
1. What is the 1?
2. How to use Detect
3. Salsa basics
4. Bachata basics

The idea is:
- first explain the concept
- then show how the app helps
- then teach the dance basics

Keep the content short and readable.

9. Copy polish
Throughout the app, tighten the wording where needed so it sounds clear and natural.

Preferred tone:
- simple
- confident
- beginner-friendly
- not too technical
- not too playful
- not too wordy

10. Output needed
Please generate updated high-fidelity mobile screens for:
- Detect start
- Detect result
- Practice home
- Quick Count setup
- Quick Count active (redesigned rhythm view)
- Find the 1 list
- Find the 1 active trainer
- Learn screen

Also keep the design system consistent across all screens:
- same color palette
- same typography hierarchy
- same card style
- same button style
- same icon treatment
- same tab bar treatment

Most important priority:
Do not reinvent the app.
Refine the current design and make it clearer, more useful, and more musically accurate for beginner Salsa and Bachata dancers.