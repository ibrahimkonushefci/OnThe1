
  # OnThe1

  This is a code bundle for OnThe1. The original project is available at https://www.figma.com/design/w5WXBt5XHGRcqZNFDtfwuw/OnThe1.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  